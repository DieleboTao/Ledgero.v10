import React from 'react';

export default function Reports(){
  return (
    <div>
      <h2>Reports</h2>
      <p>Use the backend endpoint <code>/api/reports/pnl</code> to download a CSV profit & loss.</p>
    </div>
  )
}
